

/* Reference 'botiga_comanda' */


/* Reference 'botiga_empleat' */


/* Reference 'categoria_pizza' */


/* Reference 'client_comanda' */


/* Reference 'localitat_botiga' */


/* Reference 'localitat_client' */


/* Reference 'pizza_producte' */


/* Reference 'producte_comanda' */


/* Reference 'provincia_localitat' */
