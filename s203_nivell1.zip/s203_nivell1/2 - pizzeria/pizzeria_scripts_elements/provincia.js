
db.createCollection( 'provincia', {validator: {$jsonSchema: {bsonType: 'object',title:'provincia',required: [         'nom'],properties: {nom: {bsonType: 'string'}}         }      }});  