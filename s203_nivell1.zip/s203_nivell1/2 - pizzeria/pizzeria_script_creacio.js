use lapizzeria;


db.createCollection( 'client', {validator: {$jsonSchema: {bsonType: 'object',title:'client',required: [         'nom',          'cognoms',          'adreca',          'cp',          'tel',          'id_localitat'],properties: {nom: {bsonType: 'string'},cognoms: {bsonType: 'string'},adreca: {bsonType: 'string'},cp: {bsonType: 'int'},tel: {bsonType: 'int'},id_localitat: {bsonType: 'objectId'}}         }      }});  
db.createCollection( 'localitat', {validator: {$jsonSchema: {bsonType: 'object',title:'localitat',required: [         'id_localitat',          'nom',          'id_prov'],properties: {id_localitat: {bsonType: 'objectId'},nom: {bsonType: 'string'},id_prov: {bsonType: 'objectId'}}         }      }});  
db.createCollection( 'provincia', {validator: {$jsonSchema: {bsonType: 'object',title:'provincia',required: [         'nom'],properties: {nom: {bsonType: 'string'}}         }      }});  
db.createCollection( 'producte', {validator: {$jsonSchema: {bsonType: 'object',title:'producte',required: [         'nom_prod',          'descr',          'imatge',          'preu',          'tipus'],properties: {nom_prod: {bsonType: 'string'},descr: {bsonType: 'string'},imatge: {bsonType: 'object'},preu: {bsonType: 'double'},tipus: {bsonType: 'string'}}         }      }});  
db.createCollection( 'categoria', {validator: {$jsonSchema: {bsonType: 'object',title:'categoria',required: [         'id_cate',          'nom'],properties: {id_cate: {bsonType: 'objectId'},nom: {bsonType: 'string'}}         }      }});  
db.createCollection( 'botiga', {validator: {$jsonSchema: {bsonType: 'object',title:'botiga',required: [         'adreca',          'cp',          'localitat'],properties: {adreca: {bsonType: 'string'},cp: {bsonType: 'int'},localitat: {bsonType: 'objectId'}}         }      }});  
db.createCollection( 'empleat', {validator: {$jsonSchema: {bsonType: 'object',title:'empleat',required: [         'nom',          'cognoms',          'nif',          'tel',          'funcio',          'id_botiga'],properties: {nom: {bsonType: 'string'},cognoms: {bsonType: 'string'},nif: {bsonType: 'string'},tel: {bsonType: 'int'},funcio: {bsonType: 'string'},id_botiga: {bsonType: 'objectId'}}         }      }});  
db.createCollection( 'comanda', {validator: {$jsonSchema: {bsonType: 'object',title:'comanda',required: [         'botiga',          'data_hora',          'productes',          'entrega',          'qtt',          'preu',          'id_client'],properties: {botiga: {bsonType: 'objectId'},data_hora: {bsonType: 'timestamp'},productes: {bsonType: 'array',items: {bsonType: 'string'}},entrega: {bsonType: 'object',
title:'entrega',required: [         'tipus_entrega'],properties: {tipus_entrega: {bsonType: 'string'},data_hora: {bsonType: 'binData'},id_repartidor: {bsonType: 'objectId'}}},qtt: {bsonType: 'array',items: {bsonType: 'int'}},preu: {bsonType: 'double'},id_client: {bsonType: 'objectId'}}         }      }});  
db.createCollection( 'tipus_amb_cate', {validator: {$jsonSchema: {bsonType: 'object',title:'tipus_amb_cate',required: [         'tipus'],properties: {tipus: {bsonType: 'string'},id_cate: {bsonType: 'objectId'}}         }      }});  

/* Line 'entrega-comanda' */


/* Reference 'botiga_comanda' */


/* Reference 'botiga_empleat' */


/* Reference 'categoria_pizza' */


/* Reference 'client_comanda' */


/* Reference 'localitat_botiga' */


/* Reference 'localitat_client' */


/* Reference 'pizza_producte' */


/* Reference 'producte_comanda' */


/* Reference 'provincia_localitat' */
