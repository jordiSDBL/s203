

/* Reference 'client_factura' */


/* Reference 'empleat_factura' */


/* Reference 'proveidor_ulleres' */


/* Reference 'ulleres_factura' */
