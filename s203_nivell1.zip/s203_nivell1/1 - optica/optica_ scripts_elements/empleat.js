
db.createCollection( 'empleat', {validator: {$jsonSchema: {bsonType: 'object',title:'empleat',required: [         'nom'],properties: {nom: {bsonType: 'string'}}         }      }});  