use laoptica;


db.createCollection( 'proveidor', {validator: {$jsonSchema: {bsonType: 'object',title:'proveidor',required: [         'nom',          'adreca',          'tel',          'fax',          'nif'],properties: {nom: {bsonType: 'string'},adreca: {bsonType: 'array',items: {
title:'adreca',required: [         'carrer',          'num',          'pis',          'porta',          'ciutat',          'cp',          'pais'],properties: {carrer: {bsonType: 'string'},num: {bsonType: 'int'},pis: {bsonType: 'int'},porta: {bsonType: 'int'},ciutat: {bsonType: 'string'},cp: {bsonType: 'int'},pais: {bsonType: 'string'}}}},tel: {bsonType: 'int'},fax: {bsonType: 'int'},nif: {bsonType: 'string'}}         }      }});  
db.createCollection( 'ulleres', {validator: {$jsonSchema: {bsonType: 'object',title:'ulleres',required: [         'marca',          'grad_dret',          'grad_esq',          'muntura',          'color_munt',          'color_dret',          'color_esq',          'preu'],properties: {marca: {bsonType: 'string'},grad_dret: {bsonType: 'double'},grad_esq: {bsonType: 'double'},muntura: {bsonType: 'string'},color_munt: {bsonType: 'string'},color_dret: {bsonType: 'string'},color_esq: {bsonType: 'string'},preu: {bsonType: 'double'}}         }      }});  
db.createCollection( 'client', {validator: {$jsonSchema: {bsonType: 'object',title:'client',required: [         'id',          'nom',          'adreca',          'tel',          'ae',          'data_registre'],properties: {id: {bsonType: 'objectId'},nom: {bsonType: 'string'},adreca: {bsonType: 'array',items: {
title:'adreca',required: [         'carrer',          'num',          'pis',          'porta',          'ciutat',          'cp',          'pais'],properties: {carrer: {bsonType: 'string'},num: {bsonType: 'int'},pis: {bsonType: 'int'},porta: {bsonType: 'int'},ciutat: {bsonType: 'string'},cp: {bsonType: 'int'},pais: {bsonType: 'string'}}}},tel: {bsonType: 'int'},ae: {bsonType: 'string'},data_registre: {bsonType: 'binData'},id_recomanant: {bsonType: 'int'}}         }      }});  
db.createCollection( 'empleat', {validator: {$jsonSchema: {bsonType: 'object',title:'empleat',required: [         'nom'],properties: {nom: {bsonType: 'string'}}         }      }});  
db.createCollection( 'factura', {validator: {$jsonSchema: {bsonType: 'object',title:'factura',required: [         'id_client',          'id_empleat',          'id_ulleres'],properties: {id_client: {bsonType: 'objectId'},id_empleat: {bsonType: 'objectId'},id_ulleres: {bsonType: 'array',items: {bsonType: 'objectId'}}}         }      }});  

/* Line 'client-adreca' */


/* Line 'proveidor-adreca' */


/* Reference 'client_factura' */


/* Reference 'empleat_factura' */


/* Reference 'proveidor_ulleres' */


/* Reference 'ulleres_factura' */
